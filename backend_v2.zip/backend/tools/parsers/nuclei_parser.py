"""nuclei_parser.py —— 解析 Nuclei -json 输出（每行一个 JSON 对象）"""
from __future__ import annotations
import json
import logging
from backend.agents.models import VulnFinding

logger = logging.getLogger(__name__)

SEVERITY_MAP = {"critical": "critical", "high": "high", "medium": "medium",
                "low": "low", "info": "info", "unknown": "low"}


class NucleiParser:
    def parse(self, output: str, target: str) -> list[VulnFinding]:
        findings: list[VulnFinding] = []

        for line in output.splitlines():
            line = line.strip()
            if not line or not line.startswith("{"):
                continue
            try:
                data = json.loads(line)
                info = data.get("info", {})
                severity = SEVERITY_MAP.get(info.get("severity", "low").lower(), "low")

                # 提取 CVE
                cve = None
                for tag in info.get("tags", []):
                    if tag.upper().startswith("CVE-"):
                        cve = tag.upper()
                        break
                if not cve:
                    for ref in info.get("reference", []):
                        if "CVE-" in ref.upper():
                            import re
                            m = re.search(r"CVE-\d{4}-\d+", ref, re.IGNORECASE)
                            if m:
                                cve = m.group(0).upper()
                                break

                findings.append(VulnFinding(
                    name=info.get("name", data.get("template-id", "未知漏洞")),
                    severity=severity,
                    cve=cve,
                    target=data.get("matched-at", target),
                    description=info.get("description", ""),
                    evidence=str(data.get("extracted-results", data.get("response", "")))[:10000],
                    exploitable=severity in ("critical", "high"),
                    tool="nuclei",
                ))
            except (json.JSONDecodeError, KeyError) as e:
                logger.debug(f"Nuclei 行解析失败: {e} | 行: {line[:80]}")

        logger.info(f"Nuclei 解析完成: {len(findings)} 个发现")
        return findings
