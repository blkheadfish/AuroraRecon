"""
executor.py
通用工具执行器 —— 在隔离的 Docker 容器内运行安全工具

设计原则：
  - 每次调用启动临时容器，执行完毕自动销毁（--rm）
  - 所有工具共享同一个预构建镜像 pentest-toolbox
  - 支持 async / 并发调用
  - 统一返回 ExecuteResult，屏蔽底层差异
"""

from __future__ import annotations

import asyncio
import logging
import os
import shlex
import time
from dataclasses import dataclass, field
from typing import Optional

logger = logging.getLogger(__name__)

# 工具箱镜像名称（由 docker/toolbox/Dockerfile 构建）
TOOLBOX_IMAGE = os.getenv("TOOLBOX_IMAGE", "pentest-toolbox:latest")

# 是否在宿主机直接运行工具（用于开发调试，生产必须为 False）
USE_HOST_TOOLS = os.getenv("USE_HOST_TOOLS", "false").lower() == "true"

# 容器网络（用于访问靶场，靶场和工具箱需在同一 Docker 网络）
DOCKER_NETWORK = os.getenv("DOCKER_NETWORK", "pentest_net")

# 共享数据卷（工具输出文件挂载路径）
DATA_VOLUME = os.getenv("DATA_VOLUME", "/tmp/pentest_data")


@dataclass
class ExecuteResult:
	success: bool
	stdout: str
	stderr: str
	exit_code: int
	elapsed: float  # 执行耗时（秒）
	command: str = ""  # 实际执行的命令（用于报告留痕）


class ToolExecutor:
	"""
	异步工具执行器。
 
	用法示例：
	    executor = ToolExecutor()
	    result = await executor.run(
		tool="nmap",
		args=["-sV", "-p", "80,443", "192.168.1.1"],
		timeout=120,
	    )
	    print(result.stdout)
	"""
	
	async def run(self, tool: str, args: list[str], timeout: int = 120, input_data: Optional[str] = None, env: Optional[dict[str, str]] = None, workdir: str = "/tmp", ) -> ExecuteResult:
		"""
		执行工具并返回结果。
	
		Args:
		    tool:       工具名称（如 nmap, nuclei, hydra）
		    args:       参数列表（不含工具名本身）
		    timeout:    超时秒数
		    input_data: 通过 stdin 传入的数据
		    env:        额外环境变量
		    workdir:    容器内工作目录
		"""
		cmd = self._build_command(tool, args, env, workdir)
		logger.debug(f"[Executor] 执行: {' '.join(cmd[:6])}...")  # 只打印前6个参数
		
		start = time.monotonic()
		try:
			proc = await asyncio.create_subprocess_exec(*cmd, stdin=asyncio.subprocess.PIPE if input_data else None, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE, )
			
			stdin_bytes = input_data.encode() if input_data else None
			
			try:
				stdout_bytes, stderr_bytes = await asyncio.wait_for(proc.communicate(input=stdin_bytes), timeout=timeout, )
			except asyncio.TimeoutError:
				proc.kill()
				await proc.wait()
				elapsed = time.monotonic() - start
				logger.warning(f"[Executor] 工具超时 ({timeout}s): {tool}")
				return ExecuteResult(success=False, stdout="", stderr=f"执行超时（{timeout}秒）", exit_code=-1, elapsed=elapsed, command=" ".join(cmd), )
			
			elapsed = time.monotonic() - start
			exit_code = proc.returncode or 0
			stdout = stdout_bytes.decode("utf-8", errors="replace")
			stderr = stderr_bytes.decode("utf-8", errors="replace")
			
			# 大多数扫描工具 exit_code != 0 也可能有有效输出（如 nmap 扫描无结果时返回非0）
			# 只要有 stdout 内容就视为部分成功
			success = exit_code == 0 or len(stdout.strip()) > 0
			
			logger.debug(f"[Executor] 完成: {tool} | exit={exit_code} | "
			             f"stdout={len(stdout)}B | elapsed={elapsed:.1f}s")
			
			return ExecuteResult(success=success, stdout=stdout, stderr=stderr, exit_code=exit_code, elapsed=elapsed, command=" ".join(cmd), )
		
		except FileNotFoundError:
			elapsed = time.monotonic() - start
			msg = f"命令未找到: {cmd[0]}（检查工具镜像是否构建完成）"
			logger.error(f"[Executor] {msg}")
			return ExecuteResult(success=False, stdout="", stderr=msg, exit_code=127, elapsed=elapsed, command=" ".join(cmd), )
		except Exception as e:
			elapsed = time.monotonic() - start
			logger.error(f"[Executor] 未预期异常: {e}")
			return ExecuteResult(success=False, stdout="", stderr=str(e), exit_code=-1, elapsed=elapsed, command=" ".join(cmd), )
	
	def _build_command(self, tool: str, args: list[str], env: Optional[dict[str, str]], workdir: str, ) -> list[str]:
		"""
		构造最终执行命令。
	
		- USE_HOST_TOOLS=true：直接在宿主机执行（仅开发调试）
		- 默认：docker run --rm 在容器内执行
		"""
		if USE_HOST_TOOLS:
			return [tool, *args]
		
		docker_cmd = ["docker", "run", "--rm", "-i", "--network", "host", "-w", workdir, "-v", f"{DATA_VOLUME}:/data", "--privileged", ]
		
		# 注入额外环境变量
		if env:
			for k, v in env.items():
				docker_cmd.extend(["-e", f"{k}={v}"])
		
		docker_cmd.append(TOOLBOX_IMAGE)
		docker_cmd.append(tool)
		docker_cmd.extend(args)
		
		return docker_cmd
	
	async def run_script(self, script_content: str, timeout: int = 60, shell: str = "/bin/bash", ) -> ExecuteResult:
		"""
		执行任意 shell 脚本片段（通过 stdin 传入）。
		用于需要多命令组合的场景。
		"""
		return await self.run(tool=shell, args=["-s"],  # 从 stdin 读取脚本
			timeout=timeout, input_data=script_content, )
