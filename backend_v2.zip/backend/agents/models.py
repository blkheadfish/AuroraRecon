"""
models.py
所有共享数据模型，集中定义避免循环导入
"""
from __future__ import annotations

import uuid
from datetime import datetime
from enum import Enum
from typing import Any, Optional

from pydantic import BaseModel, Field


class TaskStatus(str, Enum):
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"


class PortInfo(BaseModel):
    port: int
    protocol: str = "tcp"
    state: str = "open"
    service: str = ""
    version: str = ""
    banner: str = ""


class VulnFinding(BaseModel):
    vuln_id: str = Field(default_factory=lambda: str(uuid.uuid4())[:8])
    name: str
    severity: str = "medium"
    cve: Optional[str] = None
    target: str = ""
    port: Optional[int] = None
    description: str = ""
    evidence: str = ""
    exploitable: bool = False
    tool: str = ""


class ExploitResult(BaseModel):
    vuln_id: str
    success: bool
    shell_type: str = ""
    session_info: dict = Field(default_factory=dict)
    evidence: str = ""
    commands_run: list[str] = Field(default_factory=list)


class PentestState(BaseModel):
    task_id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    target: str = ""
    target_os: str = "unknown"
    scope_note: str = ""
    created_at: str = Field(default_factory=lambda: datetime.utcnow().isoformat())

    status: TaskStatus = TaskStatus.PENDING
    current_phase: str = "init"
    error_msg: str = ""
    phase_log: list[str] = Field(default_factory=list)

    open_ports: list[PortInfo] = Field(default_factory=list)
    os_info: dict = Field(default_factory=dict)
    web_paths: list[str] = Field(default_factory=list)
    subdomains: list[str] = Field(default_factory=list)
    raw_recon: dict = Field(default_factory=dict)

    findings: list[VulnFinding] = Field(default_factory=list)
    raw_vuln: dict = Field(default_factory=dict)

    exploit_results: list[ExploitResult] = Field(default_factory=list)
    got_shell: bool = False
    privilege_level: str = ""

    post_findings: dict = Field(default_factory=dict)

    report_path: str = ""
    report_md: str = ""

    def log(self, msg: str) -> None:
        import logging
        ts = datetime.utcnow().strftime("%H:%M:%S")
        entry = f"[{ts}] [{self.current_phase}] {msg}"
        self.phase_log.append(entry)
        logging.getLogger(__name__).info(entry)
