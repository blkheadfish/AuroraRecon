"""
orchestrator.py
主编排 Agent —— 基于 LangGraph 的渗透测试流程图

流程：
  START → recon → vuln_scan → exploit_decision → [exploit → post_exploit] → report → END
                                      ↓ (无可利用漏洞)
                                    report → END
"""
from __future__ import annotations

import json
import logging
import uuid
from typing import Optional

from langgraph.graph import END, START, StateGraph

from backend.agents.models import (ExploitResult, PentestState, PortInfo, TaskStatus, VulnFinding, )

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# 节点函数（Agent 在函数内部延迟导入，彻底避免循环依赖）
# ---------------------------------------------------------------------------

async def node_recon(state: PentestState) -> PentestState:
	from backend.agents.recon_agent import ReconAgent
	state.current_phase = "recon"
	state.status = TaskStatus.RUNNING
	state.log(f"开始侦察目标: {state.target}")
	try:
		agent = ReconAgent()
		result = await agent.run(state.target)
		state.open_ports = result.get("ports", [])
		state.os_info = result.get("os_info", {})
		state.web_paths = result.get("web_paths", [])
		state.subdomains = result.get("subdomains", [])
		state.raw_recon = result
		state.target_os = _infer_os(state.open_ports, state.os_info)
		state.log(f"侦察完成: {len(state.open_ports)} 个开放端口, OS={state.target_os}")
	except Exception as e:
		state.error_msg = str(e)
		state.log(f"侦察阶段异常: {e}")
	return state


async def node_vuln_scan(state: PentestState) -> PentestState:
	from backend.agents.vuln_agent import VulnAgent
	state.current_phase = "vuln_scan"
	state.log("开始漏洞扫描...")
	try:
		agent = VulnAgent()
		result = await agent.run(target=state.target, ports=state.open_ports, web_paths=state.web_paths, target_os=state.target_os, )
		state.findings = result.get("findings", [])
		state.raw_vuln = result
		exploitable = [f for f in state.findings if f.exploitable]
		state.log(f"漏洞扫描完成: {len(state.findings)} 个发现, {len(exploitable)} 个可利用")
	except Exception as e:
		state.error_msg = str(e)
		state.log(f"漏洞扫描阶段异常: {e}")
	return state


async def node_exploit_decision(state: PentestState) -> PentestState:
	from backend.llm.router import LLMRouter
	state.current_phase = "exploit_decision"
	exploitable = [f for f in state.findings if f.exploitable]
	if not exploitable:
		state.log("无可利用漏洞，跳过利用阶段")
		return state
	state.log(f"请求 LLM 分析 {len(exploitable)} 个可利用漏洞...")
	try:
		llm = LLMRouter()
		prompt = _build_exploit_decision_prompt(state)
		decision = await llm.chat(prompt, response_format="json")
		decision_data = json.loads(decision)
		priority_map: dict[str, dict] = {v["vuln_id"]: v for v in decision_data.get("targets", [])}
		for finding in state.findings:
			if finding.vuln_id in priority_map:
				rec = priority_map[finding.vuln_id]
				finding.exploitable = rec.get("should_exploit", finding.exploitable)
		state.log("LLM 决策完成")
	except Exception as e:
		state.log(f"LLM 决策异常（使用默认策略）: {e}")
	return state


async def node_exploit(state: PentestState) -> PentestState:
	from backend.agents.exploit_agent import ExploitAgent
	state.current_phase = "exploit"
	exploitable = [f for f in state.findings if f.exploitable]
	state.log(f"开始利用 {len(exploitable)} 个漏洞...")
	try:
		agent = ExploitAgent()
		results = await agent.run(target=state.target, findings=exploitable, target_os=state.target_os, )
		state.exploit_results = results
		successes = [r for r in results if r.success]
		state.got_shell = len(successes) > 0
		if state.got_shell:
			state.privilege_level = successes[0].session_info.get("privilege", "user")
			state.log(f"成功获取 shell，权限: {state.privilege_level}")
		else:
			state.log("所有利用尝试均未成功")
	except Exception as e:
		state.error_msg = str(e)
		state.log(f"利用阶段异常: {e}")
	return state


async def node_post_exploit(state: PentestState) -> PentestState:
	from backend.agents.post_agent import PostExploitAgent
	state.current_phase = "post_exploit"
	state.log("开始后渗透操作...")
	try:
		agent = PostExploitAgent()
		result = await agent.run(exploit_results=state.exploit_results, target_os=state.target_os, )
		state.post_findings = result
		state.privilege_level = result.get("final_privilege", state.privilege_level)
		state.log(f"后渗透完成，最终权限: {state.privilege_level}")
	except Exception as e:
		state.error_msg = str(e)
		state.log(f"后渗透阶段异常: {e}")
	return state


async def node_report(state: PentestState) -> PentestState:
	from backend.report.generator import ReportGenerator
	state.current_phase = "report"
	state.log("开始生成报告...")
	try:
		gen = ReportGenerator()
		report_md, report_path = await gen.generate(state)
		state.report_md = report_md
		state.report_path = report_path
		state.status = TaskStatus.COMPLETED
		state.log(f"报告生成完成: {report_path}")
	except Exception as e:
		state.error_msg = str(e)
		state.status = TaskStatus.FAILED
		state.log(f"报告生成异常: {e}")
	return state


# ---------------------------------------------------------------------------
# 条件边
# ---------------------------------------------------------------------------

def edge_should_exploit(state: PentestState) -> str:
	return "exploit" if any(f.exploitable for f in state.findings) else "report"


def edge_should_post(state: PentestState) -> str:
	return "post_exploit" if state.got_shell else "report"


# ---------------------------------------------------------------------------
# 构建图
# ---------------------------------------------------------------------------

def build_graph():
	graph = StateGraph(PentestState)
	
	graph.add_node("recon", node_recon)
	graph.add_node("vuln_scan", node_vuln_scan)
	graph.add_node("exploit_decision", node_exploit_decision)
	graph.add_node("exploit", node_exploit)
	graph.add_node("post_exploit", node_post_exploit)
	graph.add_node("report", node_report)
	
	graph.add_edge(START, "recon")
	graph.add_edge("recon", "vuln_scan")
	graph.add_edge("vuln_scan", "exploit_decision")
	graph.add_conditional_edges("exploit_decision", edge_should_exploit, {"exploit": "exploit", "report": "report"}, )
	graph.add_conditional_edges("exploit", edge_should_post, {"post_exploit": "post_exploit", "report": "report"}, )
	graph.add_edge("post_exploit", "report")
	graph.add_edge("report", END)
	
	return graph.compile()


# ---------------------------------------------------------------------------
# 对外入口
# ---------------------------------------------------------------------------

class Orchestrator:
	def __init__(self):
		self.graph = build_graph()
	
	async def run(self, target: str, scope_note: str = "CTF/授权靶场测试", task_id: Optional[str] = None, ) -> PentestState:
		initial_state = PentestState(target=target, scope_note=scope_note, task_id=task_id or str(uuid.uuid4()), )
		initial_state.log(f"任务启动，目标: {target}")
		final_state: PentestState = await self.graph.ainvoke(initial_state)
		return final_state
	
	async def run_stream(self, target: str, scope_note: str = "CTF/授权靶场测试", task_id: Optional[str] = None, ):
		initial_state = PentestState(target=target, scope_note=scope_note, task_id=task_id or str(uuid.uuid4()), )
		async for event in self.graph.astream(initial_state):
			for node_name, state in event.items():
				yield node_name, state


# ---------------------------------------------------------------------------
# 辅助函数
# ---------------------------------------------------------------------------

def _infer_os(ports: list[PortInfo], os_info: dict) -> str:
	"""综合 Nmap OS 指纹 + 端口特征判断操作系统"""
	# 端口特征判断
	port_nums = {p.port for p in ports}
	port_guess = "unknown"
	linux_signs = port_nums & {22, 111, 2049}
	windows_signs = port_nums & {135, 139, 445, 3389, 5985}
	if linux_signs and not windows_signs:
		port_guess = "linux"
	elif windows_signs and not linux_signs:
		port_guess = "windows"
	
	# 服务特征判断（Apache/Nginx 几乎一定是 Linux）
	service_guess = "unknown"
	for p in ports:
		combined = f"{p.service} {p.version} {p.banner}".lower()
		if any(k in combined for k in ["apache", "nginx", "openssh", "ubuntu", "debian"]):
			service_guess = "linux"
			break
		if any(k in combined for k in ["microsoft", "iis", "windows"]):
			service_guess = "windows"
			break
	
	# Nmap OS 指纹（高置信度才信任）
	nmap_guess = "unknown"
	if os_info.get("os_type") and os_info["os_type"] != "unknown":
		accuracy = int(os_info.get("accuracy", 0))
		if accuracy >= 90:
			return os_info["os_type"].lower()
		nmap_guess = os_info["os_type"].lower()
	
	# 综合决策：服务特征 > 端口特征 > 低置信度 nmap
	for guess in [service_guess, port_guess, nmap_guess]:
		if guess != "unknown":
			return guess
	
	return "unknown"


def _build_exploit_decision_prompt(state: PentestState) -> str:
	findings_json = json.dumps([f.model_dump() for f in state.findings if f.exploitable], ensure_ascii=False, indent=2, )
	ports_json = json.dumps([p.model_dump() for p in state.open_ports[:20]], ensure_ascii=False, )
	return f"""你是一名资深渗透测试工程师，正在合法授权的 CTF 靶场中进行安全测试。

目标信息:
- 地址: {state.target}
- 操作系统: {state.target_os}
- 开放端口: {ports_json}

发现的可利用漏洞:
{findings_json}

请分析上述漏洞，制定利用优先级策略，返回 JSON 格式（不含任何 markdown 代码块）：
{{
  "analysis": "整体分析描述",
  "targets": [
    {{
      "vuln_id": "漏洞ID",
      "priority": 1,
      "should_exploit": true,
      "reason": "选择原因",
      "recommended_msf_module": "模块路径（如无则为null）",
      "recommended_tool": "其他工具名称"
    }}
  ]
}}

按成功率从高到低排序，优先选择有成熟 MSF 模块或 PoC 的漏洞。"""
